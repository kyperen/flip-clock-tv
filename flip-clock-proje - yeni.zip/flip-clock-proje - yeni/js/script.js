// Otomatik Gece/Gündüz Modu - Performans İyileştirmeleri
function updateTheme() {
    const hour = new Date().getHours();
    const body = document.querySelector('body');
    const currentTheme = body.classList.contains('light-mode') ? 'light' : 'dark';
    
    // Tema değiştirme
    let newTheme;
    if (hour >= 5 && hour < 19) {
        newTheme = 'light';
    } else {
        newTheme = 'dark';
    }
    
    // Eğer tema değişmesi gerekiyorsa
    if ((newTheme === 'light' && currentTheme !== 'light') || 
        (newTheme === 'dark' && currentTheme !== 'dark')) {
        
        // Tema değişimini uygula
        if (newTheme === 'light') {
            body.classList.add('light-mode');
            body.classList.remove('dark-mode');
            
            // Şerit rengini kırmızı-turuncu yap (light mode)
            const scrollingTextContainer = document.querySelector('.scrolling-text-container');
            if (scrollingTextContainer) {
                scrollingTextContainer.style.background = 'linear-gradient(90deg, #ff0000, #ff6600, #ff0000)';
            }
        } else {
            body.classList.add('dark-mode');
            body.classList.remove('light-mode');
            
            // Şerit rengini mor yap (dark mode)
            const scrollingTextContainer = document.querySelector('.scrolling-text-container');
            if (scrollingTextContainer) {
                scrollingTextContainer.style.background = 'linear-gradient(90deg, #800080, #a000a0, #800080)';
            }
        }
        
        // Tema değişimi ile ilgili diğer ayarlamalar - Optimize edilmiş
        if (newTheme === 'light') {
            // Yıldızları bir kerede gizle
            document.querySelector('.stars').style.opacity = '0';
        } else {
            // Yıldızları bir kerede göster
            document.querySelector('.stars').style.opacity = '0.3';
        }
        
        console.log(`Tema değiştirildi: ${currentTheme} -> ${newTheme}, Saat: ${hour}`);
    }
}

// OpenWeatherMap API ile hava durumu verisi alma - optimizasyon
async function getWeatherData() {
    try {
        // API anahtarı - bu anahtarı kendi API anahtarınızla değiştirin
        const apiKey = '9d7cde1f6d07ec55650544be1631307e';
        const city = 'Istanbul'; // İstanbul için hava durumu
        
        // API çağrısı için önbellek kontrolü
        const cacheKey = `weather_${city}`;
        const cachedData = sessionStorage.getItem(cacheKey);
        const now = Date.now();
        
        // Önbellekte 30 dakikadan daha yeni veri varsa kullan
        if (cachedData) {
            const { data, timestamp } = JSON.parse(cachedData);
            // 30 dakika = 1800000 ms
            if (now - timestamp < 1800000) {
                console.log('Önbellekten hava durumu kullanılıyor');
                return data;
            }
        }
        
        // Yeni veri al
        const response = await fetch(`https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric&lang=tr`);
        
        if (!response.ok) {
            throw new Error(`API yanıt vermedi: ${response.status}`);
        }
        
        const data = await response.json();
        
        // Veriyi hazırla
        if (data.main && data.weather && data.weather.length > 0) {
            const weatherData = {
                temperature: Math.round(data.main.temp),
                location: data.name,
                icon: getWeatherEmoji(data.weather[0].id),
                description: data.weather[0].description
            };
            
            // Önbelleğe al
            sessionStorage.setItem(cacheKey, JSON.stringify({
                data: weatherData,
                timestamp: now
            }));
            
            return weatherData;
        } else {
            console.warn('API verisi beklenen formatta değil:', data);
            return getFallbackWeatherData();
        }
    } catch (error) {
        // Ağ hatası durumunda demo verilere dön
        console.warn('Hava durumu API hatası:', error.message);
        return getFallbackWeatherData();
    }
}

// Yedek hava durumu verisi (API çalışmazsa)
function getFallbackWeatherData() {
    return {
        temperature: Math.floor(Math.random() * 15) + 15,
        location: "İstanbul",
        icon: ["🌤️", "⛅", "☀️", "🌦️", "🌧️"][Math.floor(Math.random() * 5)],
        description: "Hava durumu verisi alınamadı"
    };
}

// Hava durumu koduna göre emoji seçimi
function getWeatherEmoji(weatherId) {
    // OpenWeatherMap hava durumu kodları: https://openweathermap.org/weather-conditions
    if (weatherId >= 200 && weatherId < 300) return '⛈️'; // Gök gürültülü fırtına
    if (weatherId >= 300 && weatherId < 400) return '🌧️'; // Çisenti
    if (weatherId >= 500 && weatherId < 600) return '🌧️'; // Yağmur
    if (weatherId >= 600 && weatherId < 700) return '❄️'; // Kar
    if (weatherId >= 700 && weatherId < 800) return '🌫️'; // Sis
    if (weatherId === 800) return '☀️'; // Açık hava
    if (weatherId > 800) return '⛅'; // Parçalı bulutlu
    
    return '🌤️'; // Varsayılan
}

// Hava durumu verilerine göre animasyon sınıfı ekleme - performans iyileştirmeleri
async function updateWeather() {
    try {
        const weather = await getWeatherData();
        
        if (!weather) return;
        
        const temperatureElement = document.querySelector('.temperature');
        const locationElement = document.querySelector('.location');
        const weatherIcon = document.querySelector('.weather-icon');
        
        if (temperatureElement) temperatureElement.textContent = `${weather.temperature}°C`;
        if (locationElement) locationElement.textContent = weather.location;
        
        if (weatherIcon) {
            weatherIcon.textContent = weather.icon;
        }
    } catch (err) {
        console.warn('Hava durumu güncellenirken hata:', err.message);
    }
}

// Güncellenmiş tarih fonksiyonu - saniyenin yanındaki küçük tarih için
function updateDate() {
    const now = new Date();
    const date = now.getDate();
    const month = now.getMonth() + 1; // 1-12 arası
    const year = now.getFullYear();
    
    // Tarih formatı: "24/03/2025"
    const simpleDateString = `${date.toString().padStart(2, '0')}/${month.toString().padStart(2, '0')}/${year}`;
    
    // Basit tarih bölümünü güncelle
    const simpleDate = document.querySelector('.simple-date');
    if (simpleDate && simpleDate.textContent !== simpleDateString) {
        simpleDate.textContent = simpleDateString;
    }
    
    // Özel günleri kontrol et (saatte bir kez yeterli)
    const hour = now.getHours();
    const minute = now.getMinutes();
    if (minute === 0) {
        checkSpecialDays(now);
    }
}

// Özel günleri kontrol eden fonksiyon - optimize edilmiş
function checkSpecialDays(now) {
    const day = now.getDate();
    const month = now.getMonth() + 1; // 1-12 arası
    
    // Özel günlerin listesi (gün, ay, başlık, mesaj, emoji)
    const specialDays = [
        {day: 1, month: 1, title: "Yeni Yıl", message: "Yeni Yılınız Kutlu Olsun", emoji: "🎉"},
        {day: 29, month: 10, title: "Cumhuriyet Bayramı", message: "29 Ekim Cumhuriyet Bayramı Kutlu Olsun", emoji: "🇹🇷"},
        {day: 23, month: 4, title: "23 Nisan", message: "Ulusal Egemenlik ve Çocuk Bayramı Kutlu Olsun", emoji: "👧👦"},
        {day: 19, month: 5, title: "19 Mayıs", message: "Gençlik ve Spor Bayramı Kutlu Olsun", emoji: "💪"},
        {day: 15, month: 7, title: "15 Temmuz", message: "Demokrasi ve Milli Birlik Günü", emoji: "🇹🇷"},
        {day: 30, month: 8, title: "30 Ağustos", message: "Zafer Bayramı Kutlu Olsun", emoji: "🏆"},
        {day: 10, month: 11, title: "10 Kasım", message: "Atatürk'ü Saygı ve Özlemle Anıyoruz", emoji: "🕊️"},
        {day: 14, month: 2, title: "Sevgililer Günü", message: "Sevgililer Gününüz Kutlu Olsun", emoji: "❤️"},
        {day: 8, month: 3, title: "Kadınlar Günü", message: "Dünya Kadınlar Günü Kutlu Olsun", emoji: "👩"}
    ];
    
    // Özel gün kontrol et
    for (const specialDay of specialDays) {
        if (day === specialDay.day && month === specialDay.month) {
            // Daha önce gösterilmiş mi kontrol et (günde bir kez göster)
            const cacheKey = `special_day_${day}_${month}_${now.getFullYear()}`;
            if (!sessionStorage.getItem(cacheKey)) {
                showSpecialDayNotification(specialDay);
                sessionStorage.setItem(cacheKey, 'shown');
            }
            break;
        }
    }
}

// Özel gün bildirimi göster - optimize edilmiş
function showSpecialDayNotification(specialDay) {
    const notification = document.getElementById('specialDayNotification');
    if (!notification) return;
    
    // Bildirim içeriğini hazırla
    notification.innerHTML = `
        <span class="emoji">${specialDay.emoji}</span>
        <div class="title">${specialDay.title}</div>
        <div class="message">${specialDay.message}</div>
    `;
    
    // Bildirimi göster ve animasyonu başlat
    notification.classList.add('show');
    
    // RAF ile daha pürüzsüz animasyon
    requestAnimationFrame(() => {
        notification.classList.add('animate');
    });
    
    // 15 saniye sonra bildirimi kaldır (daha uzun gösterim - daha az kesintili)
    setTimeout(() => {
        notification.classList.remove('show');
        notification.classList.remove('animate');
    }, 15000);
}

// Animasyonlu yıldızlı arkaplanı oluşturan fonksiyon - optimize edilmiş
function createStars() {
    const starsContainer = document.querySelector('.stars');
    if (!starsContainer) return;
    
    // Daha az yıldız (200 yerine 100)
    const starCount = 100; 
    
    // DOM manipülasyonlarını en aza indirmek için fragman kullan
    const fragment = document.createDocumentFragment();
    
    for (let i = 0; i < starCount; i++) {
        const star = document.createElement('div');
        star.classList.add('star');
        
        // Rastgele boyut (0.5px - 2px)
        const size = Math.random() * 1.5 + 0.5;
        star.style.width = `${size}px`;
        star.style.height = `${size}px`;
        
        // Rastgele pozisyon
        star.style.left = `${Math.random() * 100}%`;
        star.style.top = `${Math.random() * 100}%`;
        
        // Rastgele animasyon gecikmesi
        star.style.animationDelay = `${Math.random() * 4}s`;
        
        fragment.appendChild(star);
    }
    
    // Bir kerede DOM'a ekle
    starsContainer.appendChild(fragment);
}

// QR kodunu oluşturan fonksiyon
function createQRCode() {
    // QR resmine tıklandığında Trendyol sayfasını aç
    const trendyolURL = "https://www.trendyol.com/magaza/spornoktasi-m-569301?sst=0";
    const qrImage = document.querySelector('.qr-code-inline');
    
    if (qrImage) {
        qrImage.addEventListener('click', function() {
            window.open(trendyolURL, '_blank');
        });
        
        // QR resmine hover olduğunda imleç işaretçisini değiştir
        qrImage.style.cursor = 'pointer';
    }
}

// Tema değişimi bildirimini göster - optimize edilmiş
function showThemeNotification(message) {
    // Bildirim elementi var mı kontrol et, yoksa oluştur
    let notification = document.querySelector('.theme-notification');
    if (!notification) {
        notification = document.createElement('div');
        notification.className = 'theme-notification';
        document.body.appendChild(notification);
    }
    
    // Bildirim mesajını ayarla ve göster
    notification.textContent = message;
    
    // RAF ile pürüzsüz animasyon
    requestAnimationFrame(() => {
        notification.classList.add('show');
    });
    
    // 4 saniye sonra gizle (daha uzun gösterim)
    setTimeout(() => {
        notification.classList.remove('show');
    }, 4000);
}

// Marka logoları için sürekli tekrar eden kaydırma - markalar aynı sırayla tekrarlanacak
function setupInfiniteMarquee() {
    const container = document.querySelector('.brand-logos-container');
    const marqueeWrapper = document.querySelector('.marquee-wrapper');
    
    if (!container || !marqueeWrapper) return;
    
    // Mevcut logoları al
    const originalLogos = marqueeWrapper.querySelectorAll('img');
    const logoCount = originalLogos.length;
    
    if (logoCount === 0) return;
    
    // Logo grubu oluştur - ekranın genişliğine göre kaç kopyaya ihtiyaç olduğunu belirle
    const containerWidth = container.offsetWidth;
    const totalLogoWidth = Array.from(originalLogos).reduce((width, logo) => {
        const style = window.getComputedStyle(logo);
        return width + logo.offsetWidth + 
               parseFloat(style.marginLeft || 0) + 
               parseFloat(style.marginRight || 0);
    }, 0);
    
    // Tekrarlanacak set sayısı - en az 3 tam set logo olacak şekilde hesapla
    const requiredSets = Math.max(3, Math.ceil((containerWidth * 3) / totalLogoWidth));
    
    // Mevcut lgoları koruyarak, ihtiyaç duyulan kopya setlerini ekle
    for (let i = 0; i < requiredSets; i++) {
        originalLogos.forEach(logo => {
            const clone = logo.cloneNode(true);
            marqueeWrapper.appendChild(clone);
        });
    }
    
    // Animasyon süresini ayarla - ne kadar çok logo varsa, o kadar yavaş hareket etsin
    const duration = totalLogoWidth / 30; // Her 30px için 1 saniye (ayarlanabilir)
    marqueeWrapper.style.animationDuration = `${duration}s`;
    
    // Logoların tam bir tur döndüğünü göstermek için CSS'i güncelle
    const style = document.createElement('style');
    style.textContent = `
        @keyframes marquee {
            0% {
                transform: translateX(0);
            }
            100% {
                transform: translateX(calc(-${logoCount * 100}% / ${logoCount + requiredSets * logoCount}));
            }
        }
    `;
    document.head.appendChild(style);
}

// Tema değiştirme tuşu eklemek için (opsiyonel)
function setupThemeToggle() {
    // Ctrl+T tuş kombinasyonu ile tema değiştirme
    document.addEventListener('keydown', function(event) {
        if (event.ctrlKey && event.key === 't') {
            const body = document.querySelector('body');
            const scrollingTextContainer = document.querySelector('.scrolling-text-container');
            
            if (body.classList.contains('light-mode')) {
                body.classList.remove('light-mode');
                body.classList.add('dark-mode');
                
                // Şerit rengini mor yap
                if (scrollingTextContainer) {
                    scrollingTextContainer.style.background = 'linear-gradient(90deg, #800080, #a000a0, #800080)';
                }
            } else {
                body.classList.add('light-mode');
                body.classList.remove('dark-mode');
                
                // Şerit rengini kırmızı-turuncu yap
                if (scrollingTextContainer) {
                    scrollingTextContainer.style.background = 'linear-gradient(90deg, #ff0000, #ff6600, #ff0000)';
                }
            }
            
            // Yıldızları bir kerede güncelle
            const stars = document.querySelector('.stars');
            if (stars) {
                stars.style.opacity = body.classList.contains('light-mode') ? '0' : '0.3';
            }
            
            event.preventDefault();
        }
    });
}

// Başlangıç yüklemesini optimize et - güncellendi
function initApp() {
    // Tek bir fonksiyonda tüm başlangıç işlemlerini topla
    console.log("Uygulama başlatılıyor...");
    
    // jQuery ve FlipClock'un doğru yüklendiğini kontrol et
    if (typeof $ === 'undefined') {
        console.warn("jQuery yüklenemedi!");
        return;
    }
    
    if (typeof $.fn.FlipClock === 'undefined') {
        console.warn("FlipClock.js yüklenemedi!");
        return;
    }
    
    // Bildirim alanı oluştur
    if (!document.querySelector('.theme-notification')) {
        const notification = document.createElement('div');
        notification.className = 'theme-notification';
        document.body.appendChild(notification);
    }
    
    // Yıldızlı arkaplanı oluştur
    createStars();
    
    // QR kodunu ayarla
    createQRCode();
    
    // Sonsuz kayma için markaları ayarla
    setupInfiniteMarquee();
    
    // Tema değiştirme kısayolunu etkinleştir
    setupThemeToggle();
    
    // İlk yükleme için güncelleme işlemleri
    updateTheme();
    updateDate();
    updateWeather();
    
    // FlipClock'u başlat
    try {
        var clock = $('.clock-container').FlipClock({
            clockFace: 'TwentyFourHourClock',
            showSeconds: true
        });
        
        console.log("Saat başlatıldı");
    } catch (error) {
        console.warn("FlipClock başlatılırken hata:", error.message);
    }
    
    // Periyodik güncellemeler - daha hafif
    // Tema saatte bir güncelle
    setInterval(updateTheme, 60000);
    // Hava durumu 15 dakikada bir güncelle
    setInterval(updateWeather, 900000); 
    // Tarih dakikada bir güncelle
    setInterval(updateDate, 60000);
    
    console.log("Uygulama başlatıldı");
}

// Sayfa yüklendiğinde başlat
document.addEventListener('DOMContentLoaded', initApp);